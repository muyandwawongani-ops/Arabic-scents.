# Arabic Scents — Complete Website Package

This is a ready-to-deploy website for **Arabic Scents**. It includes frontend (React + Vite + Tailwind), a small Express server for Stripe Checkout, PayPal placeholders, legal pages, and a logo.

## What I prepared for you (done)
- Branded site with logo `public/images/logo.svg`
- Product pages and placeholders for three perfumes
- Cart and checkout flow that uses a server endpoint for Stripe
- Express server at `server/index.js` to handle Stripe Checkout sessions
- Public HTML pages: shipping.html, returns.html, privacy.html, terms.html
- Full README with deploy instructions

## How you get a live website (I can't deploy for you)
I cannot deploy to external hosts or purchase domains for you. But I built everything so **you or I can deploy in minutes** using these options:

### Deploy the frontend to Netlify or Vercel
1. Push this repository to GitHub.
2. In Netlify or Vercel, choose "New site from Git", connect to your repo.
3. Build command: `npm run build` — Publish directory: `dist/`
4. Set environment variables as needed for API endpoints.

### Deploy the server (Stripe) to Render / Heroku / Vercel (serverless)
1. On Render or Heroku, create a new Node service and deploy `server/`.
2. Set `STRIPE_SECRET_KEY` in the service environment variables.
3. Update `success_url` and `cancel_url` in `server/index.js` to your domain.

### Quick local test
1. `npm install`
2. `npm run dev`
3. `npm run start:server`
4. Open http://localhost:5173

## Next steps I can do for you (I will do them if you ask)
- Replace placeholder images with real product photos (you upload them or I can generate mockups)
- Fully integrate PayPal with server endpoints
- Configure and test Stripe in test mode on a deployed server
- Add email notifications, order management dashboard, or inventory system
- Create social media ad images and campaign copy

Download the complete project ZIP: `arabic-scents-complete.zip`
