import React from 'react'

export default function ProductCard({ product, onAdd }) {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <img src={product.image} alt={product.name} className="w-full h-44 object-cover" />
      <div className="p-4">
        <h4 className="font-semibold">{product.name}</h4>
        <p className="text-sm text-gray-500 mt-1">{product.description}</p>
        <div className="mt-4 flex items-center justify-between">
          <div className="text-lg font-bold">${product.price.toFixed(2)}</div>
          <button onClick={() => onAdd(product)} className="px-3 py-2 bg-indigo-600 text-white rounded-md">Add</button>
        </div>
      </div>
    </div>
  )
}
