import React from 'react'

export default function Cart({ items, onClose, onRemove, onCheckout }) {
  const total = items.reduce((s, it) => s + it.price * it.qty, 0)
  return (
    <div className="fixed right-4 top-20 w-80 bg-white shadow-lg rounded-lg p-4 z-50">
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-semibold">Your Cart</h4>
        <button onClick={onClose} className="text-sm text-gray-500">Close</button>
      </div>

      {items.length === 0 ? (
        <p className="text-gray-500">Cart is empty.</p>
      ) : (
        <div className="space-y-2">
          {items.map(it => (
            <div key={it.id} className="flex items-center justify-between">
              <div>
                <div className="font-medium">{it.name}</div>
                <div className="text-xs text-gray-500">{it.qty} × ${it.price.toFixed(2)}</div>
              </div>
              <div className="flex gap-2 items-center">
                <button onClick={() => onRemove(it.id)} className="px-2 py-1 bg-gray-100 rounded">−</button>
              </div>
            </div>
          ))}

          <div className="mt-3 border-t pt-3">
            <div className="flex justify-between font-semibold">Total <span>${total.toFixed(2)}</span></div>
            <button onClick={() => onCheckout(total)} className="mt-3 w-full px-3 py-2 bg-green-600 text-white rounded">Checkout</button>
            <a className="mt-2 block text-center text-sm text-blue-600" href={`https://wa.me/263000000000?text=Hello%20I%20want%20to%20order%20(${encodeURIComponent(items.map(i=>i.name).join(', '))})`} target="_blank" rel="noreferrer">Order via WhatsApp</a>
          </div>
        </div>
      )}
    </div>
  )
}
