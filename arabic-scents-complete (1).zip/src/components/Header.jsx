import React from 'react'

export default function Header({ cartCount, onOpenCart }) {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center text-white font-bold">AS</div>
          <div>
            <h1 className="text-lg font-semibold">Arabic Scents</h1>
            <p className="text-xs text-gray-500">Exquisite Arabian fragrances</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button onClick={onOpenCart} className="relative px-3 py-2 bg-gray-100 rounded-md">
            Cart
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center">{cartCount}</span>
            )}
          </button>
        </div>
      </div>
    </header>
  )
}
