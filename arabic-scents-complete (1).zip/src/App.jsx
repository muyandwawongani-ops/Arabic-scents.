import React, { useState } from 'react'
import products from './data/products'
import ProductCard from './components/ProductCard'
import Header from './components/Header'
import Cart from './components/Cart'

export default function App() {
  const [cart, setCart] = useState([])
  const [openCart, setOpenCart] = useState(false)

  function addToCart(product) {
    setCart(prev => {
      const found = prev.find(p=>p.id===product.id)
      if(found) return prev.map(p=>p.id===product.id?{...p, qty: p.qty+1}:p)
      return [...prev, {...product, qty:1}]
    })
  }

  function removeFromCart(id) {
    setCart(prev => prev.map(p=> p.id===id ? {...p, qty: p.qty-1} : p).filter(p=>p.qty>0))
  }

  async function handleCheckout(total) {
    // Client will call server to create Stripe session.
    try {
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: cart })
      })
      const json = await res.json()
      if(json.url) window.location = json.url
      else alert('Checkout error — see console.')
    } catch (e) {
      console.error(e)
      alert('Checkout failed — open console for details.')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 antialiased">
      <Header cartCount={cart.reduce((s,i)=>s+i.qty,0)} onOpenCart={()=>setOpenCart(true)} />

      <main className="max-w-6xl mx-auto px-6 py-10 space-y-16">
        {/* HERO */}
        <section className="grid md:grid-cols-2 gap-8 items-center bg-white p-8 rounded-lg shadow-sm">
          <div>
            <h2 className="text-4xl font-extrabold">Discover Arabic Scents — <span className="text-indigo-600">Exquisite Arabian fragrances</span></h2>
            <p className="mt-4 text-gray-600">Handcrafted perfumes inspired by Arabian olfactory traditions: oud, amber, saffron and floral accords.</p>
            <div className="mt-6 flex gap-3">
              <a href="#products" className="px-5 py-3 bg-indigo-600 text-white rounded-md">Shop now</a>
              <a href="#about" className="px-5 py-3 bg-white border rounded-md">Learn more</a>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <img src="/images/noir-oud.svg" alt="perfume" className="w-full max-w-md" />
          </div>
        </section>

        {/* PRODUCTS */}
        <section id="products">
          <h3 className="text-2xl font-semibold mb-4">Collections</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {products.map(p=> (
              <ProductCard key={p.id} product={p} onAdd={(prod)=>addToCart(prod)} />
            ))}
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-semibold">About Arabic Scents</h3>
          <p className="mt-3 text-gray-600">Arabic Scents crafts exquisite Arabian fragrances using time-honoured ingredients like oud, amber and saffron. Each bottle is carefully blended and beautifully packaged — perfect as a gift or a personal indulgence.</p>
        </section>

        {/* SHIPPING */}
        <section id="shipping" className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-semibold">Shipping</h3>
          <p className="mt-3 text-gray-600">We ship within Zambia and internationally. Local deliveries: 2-4 business days. International: 7-14 business days depending on destination. Shipping rates calculated at checkout.</p>
        </section>

        {/* RETURNS */}
        <section id="returns" className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-semibold">Returns & Exchanges</h3>
          <p className="mt-3 text-gray-600">We accept returns within 14 days of delivery for unopened bottles. Contact support at contact@arabicscents.com to start a return.</p>
        </section>

        {/* PRIVACY */}
        <section id="privacy" className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-semibold">Privacy</h3>
          <p className="mt-3 text-gray-600">We respect your privacy. Personal data is used only to process orders and for customer support. We will not share your data with third parties except for payment processors and shipping providers.</p>
        </section>

        {/* TERMS */}
        <section id="terms" className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-semibold">Terms of Service</h3>
          <p className="mt-3 text-gray-600">By using this site you agree to our terms. Full terms are available by contacting contact@arabicscents.com.</p>
        </section>

        {/* CONTACT */}
        <section id="contact" className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-semibold">Contact</h3>
          <p className="mt-3 text-gray-600">Email: <a href="mailto:contact@arabicscents.com" className="text-blue-600">contact@arabicscents.com</a> — WhatsApp: <a href="https://wa.me/263000000000" className="text-blue-600">+263 000 000 000</a>.</p>
        </section>
      </main>

      <footer className="bg-white border-t py-6 mt-10">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <img src="/images/logo.svg" alt="Arabic Scents logo" className="w-12 h-12 rounded" />
            <div>
              <div className="font-semibold">Arabic Scents</div>
              <div className="text-sm text-gray-500">Exquisite Arabian fragrances</div>
            </div>
          </div>
          <div className="flex gap-4 text-sm text-gray-500">
            <a href="#privacy">Privacy</a>
            <a href="#terms">Terms</a>
            <a href="#shipping">Shipping</a>
            <a href="#returns">Returns</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
