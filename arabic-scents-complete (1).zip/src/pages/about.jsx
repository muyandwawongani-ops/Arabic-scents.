import React from 'react'

export default function About() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-semibold">About Arabic Scents</h2>
      <p className="mt-4 text-gray-600">Arabic Scents crafts exquisite Arabian fragrances using time-honoured ingredients like oud, amber and saffron. Each bottle is carefully blended and beautifully packaged.</p>
    </div>
  )
}
