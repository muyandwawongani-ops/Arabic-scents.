// Example product data — replace images and text with yours
const products = [
  {
    id: 'p1',
    name: 'Arabic Scents — Noir Oud (50ml)',
    price: 45.0,
    description: 'Warm woody oud with saffron and amber.',
    image: '/images/noir-oud.svg'
  },
  {
    id: 'p2',
    name: 'Arabic Scents — Blossom Muse (30ml)',
    price: 20.0,
    description: 'Fresh floral with jasmine and peony.',
    image: '/images/blossom-muse.svg'
  },
  {
    id: 'p3',
    name: 'Arabic Scents — Citrus Zest (100ml)',
    price: 80.0,
    description: 'Bright zesty top notes and clean musk base.',
    image: '/images/citrus-zest.svg'
  }
]

export default products
